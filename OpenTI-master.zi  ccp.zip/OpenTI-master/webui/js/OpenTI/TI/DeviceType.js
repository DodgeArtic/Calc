define({
    TI73: 0,
    TI83p: 1,
    TI83pSE: 2,
    TI84p: 3,
    TI84pSE: 4,
    TI84pCSE: 5
});
